const { Router } = require('express');
const router = Router();

const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

//lectura de datos del archivo vinilos.json
const vinilos_inicio = fs.readFileSync('src/vinilos.json', 'utf-8');

//constante donde guardar los vinilos
const vinilos = JSON.parse(vinilos_inicio);

//peticion GET a la raíz de la aplicacion
router.get('/', (req, res) => {
    res.render('index.ejs', {
        vinilos
    });
});

//peticion GET a la url /nueva-entrada
router.get('/nueva-entrada', (req, res) => {
    res.render('nueva-entrada.ejs');
});

//peticion POST a la url /nueva-entrada
router.post('/nueva-entrada', (req, res) => {
    const { titulo, autor, imagen, genero } = req.body;

    if(!titulo || !autor || !imagen || !genero) {
        res.status(400).send('Datos de vinilo incompletos');
        return;
    }

    var vinilo = {
        id: uuidv4(),
        titulo,
        autor,
        imagen,
        genero
    };

    vinilos.push(vinilo);
    const vinilos_stringifeados = JSON.stringify(vinilos);
    fs.writeFileSync('src/vinilos.json', vinilos_stringifeados, 'utf-8');
    //res.send(vinilos);
    res.redirect('/');
});

//peticion GET para /borrar/id_del_vinilo
router.get('/borrar/:id', (req, res) => {
  

    //filtrado de vinilos excluyendo los que su id sea igual a la que se pasa por parámetro
    const vinilos_filtrados = vinilos.filter(vinilo => vinilo.id != req.params.id);
    const vinilos_stringifeados = JSON.stringify(vinilos_filtrados);
    fs.writeFileSync('src/vinilos.json', vinilos_stringifeados, 'utf-8');
    res.redirect('/');
});



module.exports = router;